BUSINESS TYCOON - Android WebView wrapper

This package wraps the supplied index.html, style.css and script.js in a native Android WebView app.
Package name: com.bodadev.businesstycoon
App label: BUSINESS TYCOON

To build with GitHub Actions:
1. Create a new empty GitHub repository.
2. Upload this ZIP file to the repository root.
3. Create .github/workflows/build.yml with the workflow instructions provided separately in chat.
4. Commit the workflow file. Open the Actions tab and download app-debug.apk from the successful run's Artifacts.
