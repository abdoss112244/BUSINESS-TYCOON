// =====================================
// BUSINESS TYCOON
// Developed by Boda Dev
// =====================================

// بيانات المشاريع
const projects = {
    store: {
        name: "متجر إلكتروني",
        price: 2000,
        income: 200,
        level: 1
    },

    cafe: {
        name: "كافيه",
        price: 5000,
        income: 450,
        level: 1
    },

    restaurant: {
        name: "مطعم",
        price: 8000,
        income: 700,
        level: 1
    },

    marketing: {
        name: "شركة تسويق",
        price: 12000,
        income: 1000,
        level: 1
    },

    software: {
        name: "شركة برمجيات",
        price: 20000,
        income: 1800,
        level: 1
    },

    factory: {
        name: "مصنع",
        price: 35000,
        income: 3000,
        level: 1
    }
};

// بيانات اللاعب
let player = JSON.parse(localStorage.getItem("businessTycoon")) || {
    money: 10000,
    bank: 10000,
    companies: [],
    records: [],
    activities: [],
    loan: 0,
    lastIncome: Date.now()
};

// =====================================
// حفظ البيانات
// =====================================

function saveGame() {
    localStorage.setItem(
        "businessTycoon",
        JSON.stringify(player)
    );
}

// =====================================
// تنسيق الأموال
// =====================================

function formatMoney(amount) {
    return Math.floor(amount).toLocaleString("en-US") + " ج.م";
}

// =====================================
// تحديث واجهة اللعبة
// =====================================

function updateGame() {

    const dailyIncome = player.companies.reduce(
        (total, company) => total + company.income,
        0
    );

    const wealth = player.money + dailyIncome * 10;

    document.getElementById("money").textContent =
        formatMoney(player.money);

    document.getElementById("wealth").textContent =
        formatMoney(wealth);

    document.getElementById("income").textContent =
        formatMoney(dailyIncome);

    document.getElementById("companyCount").textContent =
        player.companies.length;

    document.getElementById("bankBalance").textContent =
        formatMoney(player.bank);

    renderCompanies();
    renderRecords();
    renderActivities();

    saveGame();
}

// =====================================
// شراء الشركات
// =====================================

function buyCompany(id) {

    const project = projects[id];

    if (!project) return;

    if (player.companies.some(company => company.id === id)) {
        alert("أنت تمتلك هذا المشروع بالفعل!");
        return;
    }

    if (player.money < project.price) {
        alert("رصيدك غير كافٍ لشراء هذا المشروع!");
        return;
    }

    const confirmBuy = confirm(
        "هل تريد شراء " + project.name +
        " مقابل " + formatMoney(project.price) + "؟"
    );

    if (!confirmBuy) return;

    player.money -= project.price;

    player.companies.push({
        id: id,
        name: project.name,
        price: project.price,
        income: project.income,
        level: 1
    });

    addRecord(
        "شراء " + project.name,
        -project.price
    );

    addActivity(
        "تم شراء " + project.name
    );

    updateGame();

    alert("تم شراء المشروع بنجاح!");
}

// =====================================
// عرض الشركات
// =====================================

function renderCompanies() {

    const container = document.getElementById("myCompanies");

    if (!container) return;

    if (player.companies.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                لا تمتلك أي شركات حتى الآن.
            </div>
        `;
        return;
    }

    container.innerHTML = "";

    player.companies.forEach((company, index) => {

        const card = document.createElement("div");

        card.className = "company-item";

        card.innerHTML = `
            <h3>${company.name}</h3>

            <p style="color:#91a4bb;margin:10px 0;">
                مستوى الشركة: ${company.level}
            </p>

            <p style="color:#00d69a;margin-bottom:12px;">
                الربح اليومي: ${formatMoney(company.income)}
            </p>

            <button class="buy-btn"
                onclick="upgradeCompany(${index})">
                تطوير الشركة
            </button>
        `;

        container.appendChild(card);
    });
}

// =====================================
// تطوير الشركات
// =====================================

function upgradeCompany(index) {

    const company = player.companies[index];

    if (!company) return;

    const upgradePrice = company.price * company.level * 0.75;

    if (player.money < upgradePrice) {
        alert("لا يوجد رصيد كافٍ للتطوير!");
        return;
    }

    if (!confirm(
        "تطوير الشركة مقابل " +
        formatMoney(upgradePrice) + "؟"
    )) return;

    player.money -= upgradePrice;

    company.level++;

    company.income = Math.floor(company.income * 1.5);

    addRecord(
        "تطوير " + company.name,
        -upgradePrice
    );

    addActivity(
        "تم تطوير " + company.name +
        " إلى المستوى " + company.level
    );

    updateGame();

    alert("تم تطوير الشركة بنجاح!");
}

// =====================================
// الأرباح التلقائية
// =====================================

function collectIncome() {

    const now = Date.now();

    const secondsPassed =
        Math.floor((now - player.lastIncome) / 1000);

    // كل دقيقة حقيقية = يوم داخل اللعبة
    const gameDays = Math.floor(secondsPassed / 60);

    if (gameDays <= 0) return;

    const dailyIncome = player.companies.reduce(
        (total, company) => total + company.income,
        0
    );

    if (dailyIncome > 0) {

        const earned = dailyIncome * gameDays;

        player.money += earned;
        player.bank += earned;

        addRecord(
            "أرباح الشركات (" + gameDays + " يوم)",
            earned
        );

        addActivity(
            "حصلت على أرباح بقيمة " +
            formatMoney(earned)
        );
    }

    player.lastIncome += gameDays * 60000;

    updateGame();
}

// =====================================
// البنك والقروض
// =====================================

function requestLoan() {

    if (player.loan > 0) {
        alert("لديك قرض قائم بالفعل. يجب سداده أولاً.");
        return;
    }

    const amount = 5000;

    if (!confirm("هل تريد الحصول على قرض بقيمة 5,000 جنيه؟")) {
        return;
    }

    player.money += amount;
    player.bank += amount;
    player.loan = amount;

    addRecord("قرض بنكي", amount);

    addActivity("تم الحصول على قرض بنكي بقيمة 5,000 جنيه");

    updateGame();

    alert("تم إضافة القرض إلى رصيدك.");
}

// =====================================
// السجل المالي
// =====================================

function addRecord(title, amount) {

    player.records.unshift({
        title: title,
        amount: amount,
        date: new Date().toLocaleString("ar-EG")
    });

    if (player.records.length > 100) {
        player.records.pop();
    }
}

function renderRecords() {

    const container =
        document.getElementById("financialRecords");

    if (!container) return;

    if (player.records.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                لا توجد معاملات مالية حتى الآن.
            </div>
        `;
        return;
    }

    container.innerHTML = "";

    player.records.forEach(record => {

        const item = document.createElement("div");

        item.className = "activity-item";

        const color = record.amount >= 0
            ? "#00d69a"
            : "#ff647c";

        item.innerHTML = `
            <div>
                <strong>${record.title}</strong>
                <br>
                <small>${record.date}</small>
            </div>

            <strong style="color:${color}">
                ${record.amount > 0 ? "+" : ""}
                ${formatMoney(record.amount)}
            </strong>
        `;

        container.appendChild(item);
    });
}

// =====================================
// النشاطات
// =====================================

function addActivity(message) {

    player.activities.unshift({
        message: message,
        date: new Date().toLocaleTimeString("ar-EG")
    });

    if (player.activities.length > 30) {
        player.activities.pop();
    }
}

function renderActivities() {

    const container =
        document.getElementById("activityList");

    if (!container) return;

    if (player.activities.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                لا توجد نشاطات حتى الآن.
            </div>
        `;
        return;
    }

    container.innerHTML = "";

    player.activities.forEach(activity => {

        const item = document.createElement("div");

        item.className = "activity-item";

        item.innerHTML = `
            <span>${activity.message}</span>
            <small>${activity.date}</small>
        `;

        container.appendChild(item);
    });
}

// =====================================
// التنقل بين الصفحات
// =====================================

function showPage(pageId) {

    document.querySelectorAll(".page").forEach(page => {
        page.classList.remove("active");
    });

    document.querySelectorAll(".nav-btn").forEach(button => {
        button.classList.remove("active");
    });

    const selectedPage = document.getElementById(pageId);

    if (selectedPage) {
        selectedPage.classList.add("active");
    }

    document.querySelectorAll(".nav-btn").forEach(button => {

        if (button.dataset.page === pageId) {
            button.classList.add("active");
        }
    });
}

document.querySelectorAll(".nav-btn").forEach(button => {

    button.addEventListener("click", () => {
        showPage(button.dataset.page);
    });
});

// =====================================
// تشغيل اللعبة
// =====================================

function startGame() {

    collectIncome();

    updateGame();

    // تحديث الأرباح عند فتح اللعبة
    setInterval(() => {
        collectIncome();
    }, 5000);

    console.log("BUSINESS TYCOON STARTED");
    console.log("Developed by Boda Dev");
}

startGame();